//C++
/*
• Bridge.begin(): Initializes the internal serial transport mechanism; must be called in setup().
• Monitor.begin() / Monitor.println(): Replaces standard serial debugging to route text properly through the App Lab interface.
• Bridge.provide("name", function): Exposes a C++ function to the Linux/Python environment (thread-unsafe variant).
• Bridge.provide_safe("name", function): Registers a thread-safe callback updated within the main program loop.
• Bridge.call("name", args): Invokes a remote Python function from the microcontroller.
*/

void setup() {
  Bridge.begin();
  Monitor.begin();
}

void loop() { //main loop
  
}