from arduino.app_bricks.web_ui import WebUI

# Initialize the Web UI server
web_ui = WebUI()

# Add a simple REST API endpoint
web_ui.expose_api("GET", "/hello", lambda: {"message": "Hello, world!"})

# Send a message to clients over WebSocket
web_ui.send_message("hello", {"message": "Hello!"})

# Start the server
web_ui.start()

# The server will now serve static files and respond to /api/hello requests
def main():
    print("Hello World!")


if __name__ == "__main__":
    main()
